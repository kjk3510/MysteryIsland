#include "SceneCache.h"

VBOMesh::VBOMesh()
{

}

VBOMesh::~VBOMesh()
{

}