#pragma once

enum ShadingMede
{
	SHADING_MODE_WIREFRAME,
	SHADING_MODE_SHADED,
};

class VBOMesh
{
public:
	VBOMesh();

	~VBOMesh();
};